import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalTime;

public class VirtualStudyRoom {
    private static boolean isUserPresent = true;
    private static int focusMinutes = 0;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Virtual Study Room");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel statusLabel = new JLabel("Focus Mode Active", SwingConstants.CENTER);
        JLabel timerLabel = new JLabel("Focus Time: 0 min", SwingConstants.CENTER);
        JButton toggleButton = new JButton("Simulate Absence");

        toggleButton.addActionListener(e -> {
            isUserPresent = !isUserPresent;
            statusLabel.setText(isUserPresent ? "Focus Mode Active" : "User Not Present");
        });

        Timer timer = new Timer(60000, new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                if (isUserPresent) {
                    focusMinutes++;
                    timerLabel.setText("Focus Time: " + focusMinutes + " min");
                }
            }
        });
        timer.start();

        frame.setLayout(new GridLayout(3, 1));
        frame.add(statusLabel);
        frame.add(timerLabel);
        frame.add(toggleButton);
        frame.setVisible(true);
    }
}
