# Virtual Study Room with Focus Tracking (Java)

This project is a simple virtual study room built in Java using Swing for the GUI. It simulates focus tracking with the option to toggle user presence and tracks the focus time in minutes.

## Features
- Basic Swing UI
- Timer-based focus tracking
- Simulated user presence toggle

## How to Run
1. Compile: `javac src/VirtualStudyRoom.java`
2. Run: `java -cp src VirtualStudyRoom`

## Future Improvements
- Real webcam face detection using OpenCV
- Pomodoro timer integration
- Multi-user focus rooms with networking
